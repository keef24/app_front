package dependencies

object Packages {
    const val name = "io.github.droidkaigi.confsched2019"
    const val debugNameSuffix = ".debug"
}
