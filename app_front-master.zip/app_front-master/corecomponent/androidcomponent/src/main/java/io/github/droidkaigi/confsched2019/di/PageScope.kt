package io.github.droidkaigi.confsched2019.di

import javax.inject.Scope

@Scope
annotation class PageScope
