package io.github.droidkaigi.confsched2019.data.api

internal expect fun apiEndpoint(): String
