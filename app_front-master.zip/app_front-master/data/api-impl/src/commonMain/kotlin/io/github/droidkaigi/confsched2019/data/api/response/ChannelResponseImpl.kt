package io.github.droidkaigi.confsched2019.data.api.response

import kotlinx.serialization.Optional
import kotlinx.serialization.Serializable

@Serializable
data class ChannelResponseImpl(
    @Optional override val firstName: String? = null,
    @Optional override val lastName: String? = null,
    @Optional override val profilePicture: String? = null,
    @Optional override val sessions: List<Int?>? = null,
    @Optional override val tagLine: String? = null,
    @Optional override val isTopSpeaker: Boolean? = null,
    @Optional override val bio: String? = null,
    @Optional override val fullName: String? = null,
    @Optional override val links: List<String>? = null,
    @Optional override val id: String? = null
) : ChannelResponse