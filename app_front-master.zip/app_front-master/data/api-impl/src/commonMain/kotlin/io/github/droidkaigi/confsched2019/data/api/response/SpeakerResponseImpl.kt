package io.github.droidkaigi.confsched2019.data.api.response

import kotlinx.serialization.Serializable
import kotlinx.serialization.Optional

@Serializable
data class SpeakerResponseImpl(
    @Optional override val firstName: String? = null,
    @Optional override val lastName: String? = null,
    @Optional override val profilePicture: String? = null,
    @Optional override val sessions: List<Int?>? = null,
    @Optional override val tagLine: String? = null,
    @Optional override val isTopSpeaker: Boolean? = null,
    @Optional override val bio: String? = null,
    @Optional override val fullName: String? = null,
    @Optional override val links: List<String>? = null,
    @Optional override val id: String? = null
) : SpeakerResponse
