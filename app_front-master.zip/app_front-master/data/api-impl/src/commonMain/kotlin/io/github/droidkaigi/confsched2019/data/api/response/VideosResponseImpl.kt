package io.github.droidkaigi.confsched2019.data.api.response

import kotlinx.serialization.Optional
import kotlinx.serialization.Serializable

@Serializable
data class VideosResponseImpl(
    override val id: String,
    override val isServiceSession: Boolean,
    override val title: String,
    @Optional override val englishTitle: String? = null,
    override val speakers: List<String>,
    override val description: String,
    override val startsAtWithTZ: String,
    override val endsAtWithTZ: String,
    override val roomId: Int,
    override val categoryItems: List<Int>,
    override val questionAnswers: List<QuestionAnswerResponseImpl>,
    @Optional override val sessionType: String? = null,
    @Optional
    override val message: SessionMessageResponseImpl? = null,
    override val isPlenumSession: Boolean,
    override val forBeginners: Boolean,
    override val interpretationTarget: Boolean,
    @Optional override val videoUrl: String? = null,
    @Optional override val slideUrl: String? = null,
    override val duration: String?,
    override val likeCount: Int,
    override val viewCount: Int
) : VideoResponse
