package io.github.droidkaigi.confsched2019.data.api

internal actual fun apiEndpoint(): String = "https://droidkaigi2019-dev.appspot.com/api"
