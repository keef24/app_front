package io.github.droidkaigi.confsched2019.data.api

internal actual fun apiEndpoint(): String = "https://droidkaigi-api.appspot.com/2019/api"
