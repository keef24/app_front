package io.github.droidkaigi.confsched2019.data.api

import io.github.droidkaigi.confsched2019.api.BuildConfig

internal actual fun apiEndpoint(): String = BuildConfig.API_ENDPOINT
