package io.github.droidkaigi.confsched2019.data.api.parameter

enum class LangParameter(val value: String) {
    JP("jp"),
    EN("en")
}
