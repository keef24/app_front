package io.github.droidkaigi.confsched2019.data.api.response

interface LinkResponse {
    val linkType: String?
    val title: String?
    val url: String?
}
