package io.github.droidkaigi.confsched2019.data.api.response

interface QuestionAnswerResponse {
    val answerValue: String
}
