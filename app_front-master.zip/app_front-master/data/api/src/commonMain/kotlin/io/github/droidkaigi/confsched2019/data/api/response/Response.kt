package io.github.droidkaigi.confsched2019.data.api.response

interface Response {
    val sessions: List<SessionResponse>
    val videos: List<VideoResponse>
    val rooms: List<RoomResponse>?
    val speakers: List<SpeakerResponse>?
    val channels: List<ChannelResponse>?
    val categories: List<CategoryResponse>?
}
