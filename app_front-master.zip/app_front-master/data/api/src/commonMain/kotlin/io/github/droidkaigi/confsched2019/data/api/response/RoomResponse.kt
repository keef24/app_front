package io.github.droidkaigi.confsched2019.data.api.response

interface RoomResponse {
    val name: String?
    val id: Int?
    val sort: Int?
}
