package io.github.droidkaigi.confsched2019.data.api.response

interface SessionMessageResponse {
    val ja: String?
    val en: String?
}
