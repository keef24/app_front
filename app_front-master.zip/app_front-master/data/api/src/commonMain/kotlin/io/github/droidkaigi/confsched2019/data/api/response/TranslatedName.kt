package io.github.droidkaigi.confsched2019.data.api.response

interface TranslatedName {
    val ja: String
    val en: String
}
