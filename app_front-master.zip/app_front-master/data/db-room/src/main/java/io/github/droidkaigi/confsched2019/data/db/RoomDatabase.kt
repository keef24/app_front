package io.github.droidkaigi.confsched2019.data.db

import io.github.droidkaigi.confsched2019.data.api.response.Response
import io.github.droidkaigi.confsched2019.data.db.dao.ChannelDao
import io.github.droidkaigi.confsched2019.data.db.dao.SessionDao
import io.github.droidkaigi.confsched2019.data.db.dao.SessionFeedbackDao
import io.github.droidkaigi.confsched2019.data.db.dao.SessionSpeakerJoinDao
import io.github.droidkaigi.confsched2019.data.db.dao.SpeakerDao
import io.github.droidkaigi.confsched2019.data.db.dao.VideoChannelJoinDao
import io.github.droidkaigi.confsched2019.data.db.dao.VideosDao
import io.github.droidkaigi.confsched2019.data.db.entity.ChannelEntity
import io.github.droidkaigi.confsched2019.data.db.entity.SessionFeedbackEntity
import io.github.droidkaigi.confsched2019.data.db.entity.SessionWithSpeakers
import io.github.droidkaigi.confsched2019.data.db.entity.SpeakerEntity
import io.github.droidkaigi.confsched2019.data.db.entity.VideoWithChannels
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toChannelEntity
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toSessionEntities
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toSessionFeedbackEntity
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toSessionSpeakerJoinEntities
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toSpeakerEntities
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toVideoChannelJoinEntities
import io.github.droidkaigi.confsched2019.data.db.entity.mapper.toVideoEntities
import io.github.droidkaigi.confsched2019.model.SessionFeedback
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.coroutines.CoroutineContext

class RoomDatabase @Inject constructor(
    private val database: CacheDatabase,
    private val sessionDao: SessionDao,
    private val speakerDao: SpeakerDao,
    private val videosDao: VideosDao,
    private val channelsDao: ChannelDao,
    private val sessionSpeakerJoinDao: SessionSpeakerJoinDao,
    private val videoChannelJoinDao: VideoChannelJoinDao,
    private val sessionFeedbackDao: SessionFeedbackDao,
    private val coroutineContext: CoroutineContext
) : SessionDatabase {

    override suspend fun videos(): List<VideoWithChannels> {
        return videoChannelJoinDao.getAllVideos()
    }

    override suspend fun allChannels(): List<ChannelEntity> {
        return channelsDao.getAllChannels()
    }

    override suspend fun sessions(): List<SessionWithSpeakers> {
        return sessionSpeakerJoinDao.getAllSessions()
    }

    override suspend fun allSpeaker(): List<SpeakerEntity> = speakerDao.getAllSpeaker()

    override suspend fun save(apiResponse: Response) {
        withContext(coroutineContext) {
            // FIXME: SQLiteDatabaseLockedException
            database.runInTransaction {
                database.sqlite().execSQL("PRAGMA defer_foreign_keys = FALSE")
                sessionSpeakerJoinDao.deleteAll()
                speakerDao.deleteAll()
                sessionDao.deleteAll()

                val speakers = apiResponse.speakers.orEmpty().toSpeakerEntities()
                speakerDao.insert(speakers)

                val sessions = apiResponse.sessions
                val sessionEntities = sessions.toSessionEntities(
                    apiResponse.categories.orEmpty(),
                    apiResponse.rooms.orEmpty()
                )
                sessionDao.insert(sessionEntities)
                sessionSpeakerJoinDao.insert(sessions.toSessionSpeakerJoinEntities())

                videoChannelJoinDao.deleteAll()
                channelsDao.deleteAll()
                videosDao.deleteAll()

                val channels = apiResponse.channels.orEmpty().toChannelEntity()
                channelsDao.insert(channels)

                val videos = apiResponse.videos
                val videoEntities = videos.toVideoEntities(
                    apiResponse.categories.orEmpty(),
                    apiResponse.rooms.orEmpty()
                )

                videosDao.insert(videoEntities)
                videoChannelJoinDao.insert(videos.toVideoChannelJoinEntities())
            }
        }
    }

    override suspend fun sessionFeedbacks(): List<SessionFeedbackEntity> {
        return sessionFeedbackDao.sessionFeedbacks()
    }

    override suspend fun saveSessionFeedback(sessionFeedback: SessionFeedback) {
        sessionFeedbackDao.upsert(sessionFeedback.toSessionFeedbackEntity())
    }
}