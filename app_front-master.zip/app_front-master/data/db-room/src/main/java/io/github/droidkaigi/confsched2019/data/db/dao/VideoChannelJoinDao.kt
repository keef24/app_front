package io.github.droidkaigi.confsched2019.data.db.dao

import androidx.annotation.CheckResult
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import io.github.droidkaigi.confsched2019.data.db.entity.VideoChannelJoinEntityImpl
import io.github.droidkaigi.confsched2019.data.db.entity.VideoWithChannelsImpl
import org.intellij.lang.annotations.Language

@Dao
abstract class VideoChannelJoinDao {
    @Language("RoomSql")
    @Transaction
    @CheckResult
    @Query("SELECT * FROM videos")
    abstract suspend fun getAllVideos(): List<VideoWithChannelsImpl>

    @Insert
    abstract fun insert(sessionSpeakerJoin: List<VideoChannelJoinEntityImpl>)

    @Query("DELETE FROM video_speaker_join")
    abstract fun deleteAll()
}