package io.github.droidkaigi.confsched2019.data.db.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.github.droidkaigi.confsched2019.data.db.entity.SessionEntityImpl
import io.github.droidkaigi.confsched2019.data.db.entity.VideoEntityImpl

@Dao
abstract class VideosDao {
    @Query("SELECT * FROM videos")
    abstract fun videosLiveData(): LiveData<List<VideoEntityImpl>>

    @Query("SELECT * FROM videos")
    abstract fun videos(): List<VideoEntityImpl>

    @Query("DELETE FROM videos")
    abstract fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insert(sessions: List<VideoEntityImpl>)
}