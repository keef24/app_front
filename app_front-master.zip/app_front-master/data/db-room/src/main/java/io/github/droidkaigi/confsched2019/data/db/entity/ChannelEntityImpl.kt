package io.github.droidkaigi.confsched2019.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channels")
class ChannelEntityImpl(
    @PrimaryKey override var id: String,
    @ColumnInfo(name = "channel_name")
    override var name: String,
    @ColumnInfo(name = "channel_tag_line")
    override var tagLine: String?,
    @ColumnInfo(name = "channel_bio")
    override var bio: String?,
    @ColumnInfo(name = "channel_image_url")
    override var imageUrl: String?,
    @ColumnInfo(name = "channel_twitter_url")
    override var twitterUrl: String?,
    @ColumnInfo(name = "channel_company_url")
    override var companyUrl: String?,
    @ColumnInfo(name = "channel_blog_url")
    override var blogUrl: String?,
    @ColumnInfo(name = "channel_github_url")
    override var githubUrl: String?
) : ChannelEntity