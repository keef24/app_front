package io.github.droidkaigi.confsched2019.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey

@Entity(
    tableName = "video_speaker_join", primaryKeys = ["videoId", "channelId"],
    foreignKeys = [
        (ForeignKey(
            entity = VideoEntityImpl::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("videoId"),
            onDelete = ForeignKey.CASCADE
        )),
        (ForeignKey(
            entity = ChannelEntityImpl::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("channelId"),
            onDelete = ForeignKey.CASCADE
        ))]
)
class VideoChannelJoinEntityImpl(
    override val videoId: String,
    @ColumnInfo(index = true)
    override val channelId: String
) : VideoChannelJoinEntity