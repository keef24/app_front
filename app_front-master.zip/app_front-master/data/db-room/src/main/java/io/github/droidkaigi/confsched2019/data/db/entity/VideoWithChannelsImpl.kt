package io.github.droidkaigi.confsched2019.data.db.entity

import androidx.room.Embedded
import androidx.room.Relation

data class VideoWithChannelsImpl(
    @Embedded
    override val video: VideoEntityImpl
) : VideoWithChannels {
    @Relation(
        parentColumn = "id",
        entityColumn = "videoId",
        projection = ["channelId"],
        entity = VideoChannelJoinEntityImpl::class
    )
    override var channelsIdList: List<String> = emptyList()
}