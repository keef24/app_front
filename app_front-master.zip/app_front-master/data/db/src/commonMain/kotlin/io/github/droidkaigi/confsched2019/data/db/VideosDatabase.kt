package io.github.droidkaigi.confsched2019.data.db

import io.github.droidkaigi.confsched2019.data.api.response.Response
import io.github.droidkaigi.confsched2019.data.db.entity.ChannelEntity
import io.github.droidkaigi.confsched2019.data.db.entity.VideoWithChannels

//interface VideosDatabase {
//    suspend fun videos(): List<VideoWithChannels>
//    suspend fun allChannels(): List<ChannelEntity>
//    suspend fun save(apiResponse: Response)
//}