package io.github.droidkaigi.confsched2019.data.db.entity

interface CategoryEntity {
    var id: Int
    var name: String
    var jaName: String
    var enName: String
}
