package io.github.droidkaigi.confsched2019.data.db.entity

interface MessageEntity {
    var ja: String
    var en: String
}
