package io.github.droidkaigi.confsched2019.data.db.entity

interface RoomEntity {
    var id: Int
    var name: String
}
