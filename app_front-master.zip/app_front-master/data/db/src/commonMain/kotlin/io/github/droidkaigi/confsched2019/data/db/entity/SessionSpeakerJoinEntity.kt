package io.github.droidkaigi.confsched2019.data.db.entity

interface SessionSpeakerJoinEntity {
    val sessionId: String
    val speakerId: String
}
