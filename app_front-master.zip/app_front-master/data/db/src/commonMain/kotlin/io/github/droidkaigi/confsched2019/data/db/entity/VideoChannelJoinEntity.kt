package io.github.droidkaigi.confsched2019.data.db.entity

interface VideoChannelJoinEntity {
    val videoId: String
    val channelId: String
}