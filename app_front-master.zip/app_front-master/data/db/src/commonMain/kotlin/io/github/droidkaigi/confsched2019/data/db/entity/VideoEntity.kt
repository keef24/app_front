package io.github.droidkaigi.confsched2019.data.db.entity

interface VideoEntity {
    var id: String
    var title: String
    var englishTitle: String?
    var desc: String
    var stime: Long
    var etime: Long
    var sessionFormat: String?
    val language: LanguageEntity?
    val category: CategoryEntity?
    val intendedAudience: String?
    val videoUrl: String?
    val slideUrl: String?
    val isInterpretationTarget: Boolean
    val room: RoomEntity?
    val message: MessageEntity?
    val isServiceSession: Boolean
    val sessionType: String?
    val forBeginners: Boolean
    val duration: String?
    val likeCount: Int
    val viewCount: Int
}