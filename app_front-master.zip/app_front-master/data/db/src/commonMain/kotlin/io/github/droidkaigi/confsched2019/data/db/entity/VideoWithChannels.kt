package io.github.droidkaigi.confsched2019.data.db.entity

interface VideoWithChannels {
    val video: VideoEntity
    val channelsIdList: List<String>
}