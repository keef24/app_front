package io.github.droidkaigi.confsched2019.data.repository

import dagger.BindsInstance
import dagger.Component
import io.github.droidkaigi.confsched2019.data.api.DroidKaigiApi
import io.github.droidkaigi.confsched2019.data.api.GoogleFormApi
import io.github.droidkaigi.confsched2019.data.db.SessionDatabase
//import io.github.droidkaigi.confsched2019.data.db.VideosDatabase
//import io.github.droidkaigi.confsched2019.data.firestore.Firestore
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        RepositoryModule::class
    ]
)
interface RepositoryComponent {
    fun sessionRepository(): SessionRepository

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun droidKaigiApi(api: DroidKaigiApi): Builder

        @BindsInstance
        fun googleFormApi(api: GoogleFormApi): Builder

        @BindsInstance
        fun sessionDatabase(database: SessionDatabase): Builder

//        @BindsInstance
//        fun videosDatabase(database: VideosDatabase): Builder

//        @BindsInstance
//        fun firestore(firestore: Firestore): Builder

        fun build(): RepositoryComponent
    }

    companion object {
        fun builder(): Builder = DaggerRepositoryComponent.builder()
    }
}
