package io.github.droidkaigi.confsched2019.data.repository.mapper

import com.soywiz.klock.DateTime
import com.soywiz.klock.hours
import io.github.droidkaigi.confsched2019.data.db.entity.ChannelEntity
import io.github.droidkaigi.confsched2019.data.db.entity.VideoWithChannels
import io.github.droidkaigi.confsched2019.model.Category
import io.github.droidkaigi.confsched2019.model.Channel
import io.github.droidkaigi.confsched2019.model.Lang
import io.github.droidkaigi.confsched2019.model.LocaledString
import io.github.droidkaigi.confsched2019.model.Room
import io.github.droidkaigi.confsched2019.model.ServiceVideo
import io.github.droidkaigi.confsched2019.model.SessionType
import io.github.droidkaigi.confsched2019.model.SpeechVideo
import io.github.droidkaigi.confsched2019.model.Video

private val jstOffset = 9.hours

fun VideoWithChannels.toVideos(
    channelEntities: List<ChannelEntity>,
//    favList: List<String>?,
    firstDay: DateTime
): Video {
    return if (video.isServiceSession) {

        ServiceVideo(
            id = video.id,
            dayNumber = if (DateTime(video.stime).yearInt == 2018) 1 else 2,
            startTime = DateTime.fromUnix(video.stime),
            endTime = DateTime.fromUnix(video.etime),
            title = LocaledString(ja = video.title, en = requireNotNull(video.englishTitle)),
            desc = video.desc,
            room = requireNotNull(video.room).let { room -> Room(room.id, room.name) },
            sessionType = SessionType.of(video.sessionType),
//            isFavorited = favList!!.contains(video.id)
            isFavorited = false
        )
    } else {

        val channels = channelsIdList.map { speakerId ->
            val channelEntity = channelEntities.first { it.id == speakerId }
            channelEntity.toChannel()
        }


        SpeechVideo(
            id = video.id,
            dayNumber = if (DateTime(video.stime).yearInt == 2018) 1 else 2,
            startTime = DateTime.fromUnix(video.stime),
            endTime = DateTime.fromUnix(video.etime),
            title = LocaledString(video.title, requireNotNull(video.englishTitle)),
            desc = video.desc,
            room = Room(requireNotNull(video.room?.id), requireNotNull(video.room?.name)),
            format = requireNotNull(video.sessionFormat),
            lang = Lang.findLang(requireNotNull(video.language?.name)),
            category = video.category?.let {
                Category(
                    it.id,
                    LocaledString(
                        ja = it.name,
                        en = it.name
                    )
                )
            },
            intendedAudience = video.intendedAudience,
            videoUrl = video.videoUrl,
            slideUrl = video.slideUrl,
            isInterpretationTarget = video.isInterpretationTarget,
            isFavorited = false,
//            isFavorited = favList!!.contains(video.id),
            channels = channels,
            message = video.message?.let { LocaledString(it.ja, it.en) },
            forBeginners = video.forBeginners,
            duration = video.duration!!,
            likeCount = video.likeCount,
            viewCount = video.viewCount
        )
    }
}

fun ChannelEntity.toChannel(): Channel = Channel(
    id = id,
    name = name,
    tagLine = tagLine,
    bio = bio,
    imageUrl = imageUrl,
    twitterUrl = twitterUrl,
    companyUrl = companyUrl,
    blogUrl = blogUrl,
    githubUrl = githubUrl
)

//fun SessionFeedbackEntity.toSessionFeedback(): SessionFeedback =
//    SessionFeedback(
//        sessionId = sessionId,
//        totalEvaluation = totalEvaluation,
//        relevancy = relevancy,
//        asExpected = asExpected,
//        difficulty = difficulty,
//        knowledgeable = knowledgeable,
//        comment = comment,
//        submitted = submitted
//    )
