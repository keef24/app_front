package io.github.droidkaigi.confsched2019.session.di

import javax.inject.Scope

@Scope
annotation class SessionPageScope
