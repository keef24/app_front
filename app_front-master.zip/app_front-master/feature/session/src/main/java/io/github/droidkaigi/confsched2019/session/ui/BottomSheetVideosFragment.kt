package io.github.droidkaigi.confsched2019.session.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.transition.AutoTransition
import androidx.transition.TransitionManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.databinding.ViewHolder
import io.github.droidkaigi.confsched2019.ext.changed
import io.github.droidkaigi.confsched2019.model.SessionPage
import io.github.droidkaigi.confsched2019.model.SpeechVideo
import io.github.droidkaigi.confsched2019.model.Video
import io.github.droidkaigi.confsched2019.session.R
import io.github.droidkaigi.confsched2019.session.databinding.FragmentBottomSheetVideosBinding
import io.github.droidkaigi.confsched2019.session.ui.actioncreator.SessionPageActionCreator
import io.github.droidkaigi.confsched2019.session.ui.actioncreator.VideoPagesActionCreator
import io.github.droidkaigi.confsched2019.session.ui.item.SessionItem
import io.github.droidkaigi.confsched2019.session.ui.item.SpeechVideoItem
import io.github.droidkaigi.confsched2019.session.ui.store.SessionPageStore
import io.github.droidkaigi.confsched2019.session.ui.store.VideoPagesStore
import io.github.droidkaigi.confsched2019.session.ui.widget.DaggerFragment
import io.github.droidkaigi.confsched2019.session.ui.widget.SessionsItemDecoration
import io.github.droidkaigi.confsched2019.session.ui.widget.VideosItemDecoration
import io.github.droidkaigi.confsched2019.widget.BottomSheetBehavior
import me.tatarka.injectedvmprovider.InjectedViewModelProviders
import me.tatarka.injectedvmprovider.ktx.injectedViewModelProvider
import javax.inject.Inject
import javax.inject.Provider

class BottomSheetVideosFragment : DaggerFragment() {
    private lateinit var binding: FragmentBottomSheetVideosBinding

    @Inject
    lateinit var videosPagesStoreProvider: Provider<VideoPagesStore>

    @Inject
    lateinit var speechVideoItemFactory: SpeechVideoItem.Factory

    @Inject
    lateinit var sessionPageActionCreator: SessionPageActionCreator

    @Inject
    lateinit var sessionPageStoreFactory: SessionPageStore.Factory

    @Inject
    lateinit var sessionPageFragmentProvider: Provider<SessionPageFragment>

    private val videoPagesStore: VideoPagesStore by lazy {
        InjectedViewModelProviders.of(requireActivity())
            .get(videosPagesStoreProvider)
    }

    private val sessionPageStore: SessionPageStore by lazy {
        sessionPageFragmentProvider.get().injectedViewModelProvider
            .get(SessionPageStore::class.java.name) {
                sessionPageStoreFactory.create(SessionPage.pages[1])
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_bottom_sheet_videos,
            container,
            false
        )

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val groupAdapter = GroupAdapter<ViewHolder<*>>()

        binding.sessionsRecycler.apply {
            adapter = groupAdapter

            addItemDecoration(VideosItemDecoration(requireContext(), groupAdapter))
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    binding.sessionsListHeaderShadow.isVisible = recyclerView.canScrollVertically(-1)
                }
            })
        }

        val onFilterButtonClick: (View) -> Unit = {
            sessionPageActionCreator.toggleFilterExpanded(SessionPage.pageOfDay(2))
        }

        binding.sessionsBottomSheetShowFilterButton.setOnClickListener(onFilterButtonClick)
        binding.sessionsBottomSheetHideFilterButton.setOnClickListener(onFilterButtonClick)

        videoPagesStore.allVideos().changed(viewLifecycleOwner) { videos ->
            val items = videos
                .filterIsInstance<SpeechVideo>().map<Video, Item<*>> { video ->

                    speechVideoItemFactory.create(
                        video as SpeechVideo,
                        SessionPagesFragmentDirections.actionSessionToVideoDetail(video.id),
                        SessionPagesFragmentDirections.actionSessionToVideoDetail(video.id), // TODO Survey
                        true
                    )
                }
            groupAdapter.update(items)

            videoPagesStore.filters.changed(viewLifecycleOwner) {
                binding.isFiltered = it.isFiltered()
            }
            sessionPageStore.filterSheetState.changed(viewLifecycleOwner) { newState ->
                if (newState == BottomSheetBehavior.STATE_EXPANDED ||
                    newState == BottomSheetBehavior.STATE_COLLAPSED
                ) {
                    TransitionManager.beginDelayedTransition(
                        binding.root as ViewGroup, AutoTransition().apply {
                            excludeChildren(binding.sessionsBottomSheetTitle, true)
                            excludeChildren(binding.sessionsRecycler, true)
                        })
                    val isCollapsed = newState == BottomSheetBehavior.STATE_COLLAPSED
                    binding.isCollapsed = isCollapsed
                }
            }

        }
    }

    companion object {
        fun newInstance(): BottomSheetVideosFragment {
            return BottomSheetVideosFragment()
        }
    }
}

