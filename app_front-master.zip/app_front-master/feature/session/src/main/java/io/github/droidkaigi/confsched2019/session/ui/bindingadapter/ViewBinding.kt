package io.github.droidkaigi.confsched2019.session.ui.bindingadapter

import android.view.View
import androidx.databinding.BindingAdapter
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

@BindingAdapter(value = ["visibleGone"])
fun showHide(view: View, show: Boolean) {
    view.visibility = if (show) View.VISIBLE else View.GONE
}

@BindingAdapter(value = ["cueVideoUrl"])
fun cueVideoUrl(view: YouTubePlayerView, url: String) {
    view.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
        override fun onReady(youTubePlayer: YouTubePlayer) {

            Regex("(?<=https\\:\\/\\/youtu\\.be\\/).+\$").find(url)?.let {
                youTubePlayer.cueVideo(it.value, 0f)
            }
        }
    })
}