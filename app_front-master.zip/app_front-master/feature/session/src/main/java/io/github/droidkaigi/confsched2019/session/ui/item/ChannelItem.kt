package io.github.droidkaigi.confsched2019.session.ui.item

import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat
import com.squareup.inject.assisted.Assisted
import com.squareup.inject.assisted.AssistedInject
import com.squareup.picasso.Picasso
import com.xwray.groupie.databinding.BindableItem
import io.github.droidkaigi.confsched2019.item.EqualableContentsProvider
import io.github.droidkaigi.confsched2019.model.Channel
import io.github.droidkaigi.confsched2019.model.Speaker
import io.github.droidkaigi.confsched2019.session.R
import io.github.droidkaigi.confsched2019.session.databinding.ItemChannelBinding
import io.github.droidkaigi.confsched2019.session.databinding.ItemSpeakerBinding
import jp.wasabeef.picasso.transformations.CropCircleTransformation

class ChannelItem @AssistedInject constructor(
    @Assisted val channel: Channel,
    @Assisted val clickNavDirection: NavDirections,
    @Assisted val query: String?,
    val navController: NavController
) : BindableItem<ItemChannelBinding>(channel.id.hashCode().toLong()),
    EqualableContentsProvider {

    @AssistedInject.Factory
    interface Factory {
        fun create(
            channel: Channel,
            clickNavDirection: NavDirections,
            query: String? = null
        ): ChannelItem
    }

    override fun getLayout(): Int = R.layout.item_channel

    override fun bind(itemBinding: ItemChannelBinding, position: Int) {
        itemBinding.speaker = channel
        itemBinding.query = query
        val context = itemBinding.speakerImage.context
        val placeHolderColor = ContextCompat.getColor(
            context,
            R.color.colorOnBackgroundSecondary
        )
        val placeHolder = VectorDrawableCompat.create(
            context.resources,
            R.drawable.ic_person_outline_black_24dp,
            null
        )
        placeHolder?.setTint(placeHolderColor)
        channel.imageUrl?.let { imageUrl ->
            itemBinding.speakerImage.clearColorFilter()
            Picasso.get()
                .load(imageUrl)
                .transform(CropCircleTransformation())
                .apply {
                    placeHolder?.let {
                        placeholder(it)
                    }
                }
                .into(itemBinding.speakerImage)
        } ?: run {
            itemBinding.speakerImage.setImageDrawable(placeHolder)
        }

        itemBinding.root.setOnClickListener {
            navController.navigate(
                clickNavDirection,
                FragmentNavigatorExtras(
                    itemBinding.speakerImage to channel.id
                )
            )
        }
    }

    override fun providerEqualableContents(): Array<*> = arrayOf(
        channel,
        if (isContainsQuery()) query else null
    )

    private fun isContainsQuery() = query?.let {
        channel.name.toLowerCase().contains(it.toLowerCase())
    } ?: false

    override fun equals(other: Any?): Boolean {
        return isSameContents(other)
    }

    override fun hashCode(): Int {
        return contentsHash()
    }
}
