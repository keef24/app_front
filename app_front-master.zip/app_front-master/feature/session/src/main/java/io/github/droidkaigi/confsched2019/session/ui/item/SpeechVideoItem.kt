package io.github.droidkaigi.confsched2019.session.ui.item

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.size
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat
import com.google.android.material.chip.Chip
import com.squareup.inject.assisted.Assisted
import com.squareup.inject.assisted.AssistedInject
import com.squareup.picasso.Picasso
import com.squareup.picasso.Target
import com.xwray.groupie.databinding.BindableItem
import io.github.droidkaigi.confsched2019.item.EqualableContentsProvider
import io.github.droidkaigi.confsched2019.model.Channel
import io.github.droidkaigi.confsched2019.model.SpeechVideo
import io.github.droidkaigi.confsched2019.model.defaultLang
import io.github.droidkaigi.confsched2019.session.R
import io.github.droidkaigi.confsched2019.session.databinding.ItemVideoBinding
import io.github.droidkaigi.confsched2019.session.ui.actioncreator.SessionContentsActionCreator
import io.github.droidkaigi.confsched2019.session.ui.bindingadapter.setHighlightText
import io.github.droidkaigi.confsched2019.util.lazyWithParam
import jp.wasabeef.picasso.transformations.CropCircleTransformation
import kotlin.math.max

class SpeechVideoItem @AssistedInject constructor(
    @Assisted override val video: SpeechVideo,
    @Assisted val detailNavDirections: NavDirections,
    @Assisted val surveyNavDirections: NavDirections,
    @Assisted val hasStartPadding: Boolean,
    @Assisted val query: String?,
    val navController: NavController,
    val sessionContentsActionCreator: SessionContentsActionCreator
) : BindableItem<ItemVideoBinding>(
    video.id.hashCode().toLong()
), VideoItem, EqualableContentsProvider {
    val speechVideo get() = video

    @AssistedInject.Factory
    interface Factory {
        fun create(
            video: SpeechVideo,
            detailNavDirections: NavDirections,
            surveyNavDirections: NavDirections,
            hasStartPadding: Boolean,
            query: String? = null
        ): SpeechVideoItem
    }

    val layoutInflater by lazyWithParam<Context, LayoutInflater> { context ->
        LayoutInflater.from(context)
    }

    override fun bind(viewBinding: ItemVideoBinding, position: Int) {
        with(viewBinding) {
            root.setOnClickListener {
                try {
                    navController.navigate(detailNavDirections)
                } catch (e: IllegalArgumentException) {
                    // FIXME: When launching the app and click session multiple times, cause Exception
                }
            }
            session = speechVideo
            lang = defaultLang()
            hasStartPadding = this@SpeechVideoItem.hasStartPadding
            query = this@SpeechVideoItem.query
            favorite.setOnClickListener {
                // apply state immediately
                viewBinding.session = speechVideo.copy(
                    isFavorited = !speechVideo.isFavorited
                )
                sessionContentsActionCreator.toggleFavorite(speechVideo)
            }

            timeAndRoom.text = "${speechVideo.viewCount} Views / ${speechVideo.likeCount} Likes "

            survey.setOnClickListener {
                navController.navigate(surveyNavDirections)
            }

            val category = speechVideo.category?.name?.getByLang(defaultLang()) ?: ""

            val categories = category
                .split(",")
                .filter { it.isNotEmpty() }

            categories.getOrNull(0)?.let {
                categoryChip0.visibility = View.VISIBLE
                categoryChip0.text = it
            }

            categories.getOrNull(1)?.let {
                categoryChip1.visibility = View.VISIBLE
                categoryChip1.text = it
            }

            categories.getOrNull(2)?.let {
                categoryChip2.visibility = View.VISIBLE
                categoryChip2.text = it
            }

            bindChannel()

            speechVideo.message?.let { message ->
                this@with.message.text = message.getByLang(defaultLang())
            }
        }
    }

    private fun ItemVideoBinding.bindChannel() {
        (0 until max(
            speakers.size, speechVideo.channels.size
        )).forEach { index ->
            val existSpeakerView = speakers.getChildAt(index) as? ViewGroup
            val channel: Channel? = speechVideo.channels.getOrNull(index)
            if (existSpeakerView == null && channel == null) {
                return@forEach
            }
            if (existSpeakerView != null && channel == null) {
                // Cache for performance
                existSpeakerView.isVisible = false
                return@forEach
            }
            if (existSpeakerView == null && channel != null) {
                val speakerView = layoutInflater.get(root.context).inflate(
                    R.layout.layout_speaker, speakers, false
                ) as ViewGroup
                val textView: TextView = speakerView.findViewById(R.id.speaker)
                bindChannelData(channel, textView)

                speakers.addView(speakerView)
                return@forEach
            }
            if (existSpeakerView != null && channel != null) {
                existSpeakerView.isVisible = true

                val textView: TextView = existSpeakerView.findViewById(R.id.speaker)
                textView.text = channel.name
                bindChannelData(channel, textView)
            }
        }
    }

    private fun bindChannelData(
        speaker: Channel,
        textView: TextView
    ) {
        textView.text = speaker.name
        setHighlightText(textView, query)
        val imageUrl = speaker.imageUrl
        val context = textView.context
        val placeHolder = run {
            VectorDrawableCompat.create(
                context.resources,
                R.drawable.ic_person_outline_black_24dp,
                null
            )?.apply {
                setTint(
                    ContextCompat.getColor(
                        context,
                        R.color.colorOnBackgroundSecondary
                    )
                )
            }
        }

        imageUrl ?: run {
            placeHolder?.let {
                textView.setLeftDrawable(it)
            }
        }

        Picasso
            .get()
            .load(imageUrl)
            .transform(CropCircleTransformation())
            .apply {
                if (placeHolder != null) {
                    placeholder(placeHolder)
                }
            }
            .into(object : Target {
                override fun onPrepareLoad(placeHolderDrawable: Drawable?) {
                    placeHolderDrawable?.let {
                        textView.setLeftDrawable(it)
                    }
                }
                override fun onBitmapFailed(e: Exception?, errorDrawable: Drawable?) {
                }
                override fun onBitmapLoaded(bitmap: Bitmap?, from: Picasso.LoadedFrom?) {
                    val res = textView.context.resources
                    val drawable = BitmapDrawable(res, bitmap)
                    textView.setLeftDrawable(drawable)
                }
            })
    }

    fun TextView.setLeftDrawable(drawable: Drawable) {
        val res = context.resources
        val widthDp = 16
        val heightDp = 16
        val widthPx = (widthDp * res.displayMetrics.density).toInt()
        val heightPx = (heightDp * res.displayMetrics.density).toInt()
        drawable.setBounds(0, 0, widthPx, heightPx)
        setCompoundDrawables(drawable, null, null, null)
    }

    override fun getLayout(): Int = R.layout.item_video

    override fun providerEqualableContents(): Array<*> = arrayOf(video, if (isContainsQuery()) query else null)

    private fun isContainsQuery() = query?.let {
        when {
            video.title.getByLang(defaultLang())
                .toLowerCase()
                .contains(query.toLowerCase()) -> true
            video.channels.find {
                it.name
                    .toLowerCase()
                    .contains(query.toLowerCase())
            } != null -> true
            else -> false
        }
    } ?: false

    override fun equals(other: Any?): Boolean {
        return isSameContents(other)
    }

    override fun hashCode(): Int {
        return contentsHash()
    }
}
