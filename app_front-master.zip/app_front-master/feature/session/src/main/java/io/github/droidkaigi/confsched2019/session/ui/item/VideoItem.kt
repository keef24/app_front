package io.github.droidkaigi.confsched2019.session.ui.item

import io.github.droidkaigi.confsched2019.model.Video

interface VideoItem {
    val video: Video
}
