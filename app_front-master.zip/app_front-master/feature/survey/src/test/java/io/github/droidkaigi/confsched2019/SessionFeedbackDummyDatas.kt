package io.github.droidkaigi.confsched2019

import io.github.droidkaigi.confsched2019.model.SessionFeedback

fun dummySessionFeedbackData(): SessionFeedback {
    return SessionFeedback(
        "12345",
        5,
        4,
        3,
        2,
        1,
        "",
        true
    )
}
