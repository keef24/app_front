package io.github.droidkaigi.confsched2019.di

import dagger.Module
import dagger.Provides
import io.github.droidkaigi.confsched2019.data.api.DroidKaigiApi
import io.github.droidkaigi.confsched2019.data.api.GoogleFormApi
import io.github.droidkaigi.confsched2019.data.db.SessionDatabase
//import io.github.droidkaigi.confsched2019.data.db.VideosDatabase
//import io.github.droidkaigi.confsched2019.data.firestore.Firestore
import io.github.droidkaigi.confsched2019.data.repository.RepositoryComponent
import io.github.droidkaigi.confsched2019.data.repository.SessionRepository
import javax.inject.Singleton

@Module
object RepositoryComponentModule {
    @JvmStatic
    @Provides
    @Singleton
    fun provideRepository(
        repositoryComponent: RepositoryComponent
    ): SessionRepository {
        return repositoryComponent.sessionRepository()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideRepositoryComponent(
        droidKaigiApi: DroidKaigiApi,
        googleFormApi: GoogleFormApi,
        sessionDatabase: SessionDatabase
//        videosDatabase: VideosDatabase,
//        firestore: Firestore
    ): RepositoryComponent {
        return RepositoryComponent.builder()
            .droidKaigiApi(droidKaigiApi)
            .googleFormApi(googleFormApi)
            .sessionDatabase(sessionDatabase)
//            .videosDatabase(videosDatabase)
//            .firestore(firestore)
            .build()
    }
}
