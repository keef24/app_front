package io.github.droidkaigi.confsched2019.model

import android.os.Parcelable

actual interface AndroidParcel : Parcelable
