package io.github.droidkaigi.confsched2019.model

import kotlinx.android.parcel.Parcelize

actual typealias AndroidParcelize = kotlinx.android.parcel.Parcelize
