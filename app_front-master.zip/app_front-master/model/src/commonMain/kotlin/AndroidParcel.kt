package io.github.droidkaigi.confsched2019.model

expect interface AndroidParcel
