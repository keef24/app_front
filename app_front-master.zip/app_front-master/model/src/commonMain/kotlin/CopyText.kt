package io.github.droidkaigi.confsched2019.model

data class CopyText(
    val text: String,
    val copied: Boolean
)
