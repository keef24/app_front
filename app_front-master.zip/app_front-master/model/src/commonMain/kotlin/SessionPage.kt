package io.github.droidkaigi.confsched2019.model

sealed class SessionPage {

    open class Day(
        override val title: String,
        val day: Int
    ) : SessionPage()

    object Classes : Day("Classes", 1)
    object Videos : Day("Videos", 2)
    object Favorite : Day("MyPlan", 3)

    abstract val title: String

    companion object {
        val pages = listOf(Classes, Videos, Favorite)

        fun pageOfDay(dayNumber: Int): Day {
            return pages.first { it.day == dayNumber }
        }
    }
}
