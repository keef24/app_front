package io.github.droidkaigi.confsched2019.model

class SystemProperty(val lang: Lang)
